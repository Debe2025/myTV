﻿# myTV Kodi Installer

Kodi addon that configures PVR IPTV Simple for myTV.

## Install
1. Zip this folder as `repository.mytv-1.0.0.zip`
2. Kodi -> Settings -> Add-ons -> Install from zip file
3. Run **myTV Installer** from Program add-ons
4. Choose Local or GitHub Pages source

## Details
- Country  : Canada (ca)
- Channels : 1644
- Playlist : https://Debe2025.github.io/myTV/playlist.m3u8
- EPG      : https://Debe2025.github.io/myTV/epg.xml.gz
